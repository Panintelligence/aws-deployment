'''Panintelligence 2021 - EFS lambda copy utility'''

import os
import logging
import shutil

import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def get_bucket_name(record):
    '''retrieve bucket name from s3 triggered event'''
    try:
        return record['s3']['bucket']['name']
    except KeyError as key_error:
        logger.error('Unable to find "name" key in record bucket')
        raise Exception from key_error

def get_object_key(record):
    '''retrieve object key from s3 triggered event'''
    try:
        return record['s3']['object']['key']
    except KeyError as key_error:
        logger.error('Unable to find "key" key in record object')
        raise Exception from key_error
    return record['s3']['object']['key']

def get_object_type(record):
    '''The part before the first / forms the object type and will decide
    where it loads to (if it can be loaded)'''
    allowed_types = os.environ.get('allowed_types','').split(',')
    try:
        key = record['s3']['object']['key']
        if '/' in key:
            file_type = key[0:key.find('/')]
            if file_type in allowed_types:
                return file_type
            error = 'file_type not found in allowed types'
            logger.error(error)
            raise Exception(error)
        logger.error('unable to find separator')
        raise Exception('could not determine what the record file_type is')
    except KeyError as key_error:
        logger.error('Unable to find "key" for record file_type')
        raise Exception from key_error

def get_file_name_from_object_key(object_key, separator = '/'):
    '''retrieves the file name from the object'''
    if separator in object_key:
        return object_key[object_key.rfind(separator)+1: len(object_key)]
    logger.error('Could not find separator in %s', object_key)
    raise Exception(f'could not find separator {separator} in {object_key}')

def copy_file(source_file, target_file_name, file_type):
    '''copy the file from local system to efs volume'''
    target_file = os.path.join('efs', file_type, target_file_name)
    shutil.copyfile(source_file, target_file)

def change_file_owner(target_file_name, file_type, target_owner, target_group):
    '''change the owner of the target file'''
    target_file = os.path.join('efs', file_type, target_file_name)
    shutil.chown(target_file,user=target_owner, group=target_group)

class EfsTrigger:
    '''EFS lambda trigger code'''
    def __init__(self):
        self.s3_client = boto3.client('s3')

    def download_from_s3(self, bucket_name, object_name, target_file_name):
        '''download object from s3 to store on /tmp'''
        target_name = os.path.join('tmp', target_file_name)
        self.s3_client.download(bucket_name, object_name, target_name)
        return target_name

    def run_migrations(self, event):
        '''entry point for the program'''
        for record in event['Records']:
            source_bucket = get_bucket_name(record)
            file_type = get_object_type(record)
            source_object_key = get_object_key(record)
            target_file_name = get_file_name_from_object_key(source_object_key)
            source_file = self.download_from_s3(source_bucket, source_object_key, target_file_name)

            copy_file(source_file, target_file_name, file_type)
            change_file_owner(target_file_name,
                              file_type,
                              os.environ.get('file_owner','pi-user'),
                              os.environ.get('file_group','pi-user'))

efs_trigger = EfsTrigger()

def lambda_handler(event, context):
    '''call this from AWS'''
    del context
    efs_trigger.run_migrations(event)

if __name__ == '__main__':
    lambda_handler(event={}, context={})
