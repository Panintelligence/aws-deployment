'''Panintelligence 2021 - EFS lambda copy utility'''

import os
import logging
import shutil

import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def get_bucket_name(record):
    '''retrieve bucket name from s3 triggered event'''
    try:
        return record['s3']['bucket']['name']
    except KeyError as key_error:
        logger.error('Unable to find "name" key in record bucket')
        raise Exception from key_error

def get_object_key(record):
    '''retrieve object key from s3 triggered event'''
    try:
        return record['s3']['object']['key']
    except KeyError as key_error:
        logger.error('Unable to find "key" key in record object')
        raise Exception from key_error
    return record['s3']['object']['key']

def get_object_type(record):
    '''The part before the first / forms the object type and will decide
    where it loads to (if it can be loaded)'''
    allowed_types = os.environ.get('allowed_types','').split(',')
    try:
        key = record['s3']['object']['key']
        if '/' in key:
            file_type = key[0:key.find('/')]
            if file_type in allowed_types:
                return file_type
            error = 'file_type not found in allowed types'
            logger.error(error)
            raise Exception(error)
        logger.error('unable to find separator')
        raise Exception('could not determine what the record file_type is')
    except KeyError as key_error:
        logger.error('Unable to find "key" for record file_type')
        raise Exception from key_error

def get_file_name_from_object_key(object_key, separator = '/'):
    '''retrieves the file name from the object'''
    if separator in object_key:
        return object_key[object_key.rfind(separator)+1: len(object_key)]
    logger.error('Could not find separator in %s', object_key)
    raise Exception(f'could not find separator {separator} in {object_key}')

def copy_path(file_type):
    '''copy the file from local system to efs volume'''
    logger.info('copy_file target_file_name: %s', target_file_name)
    logger.info('efs local mount directory: %s', os.listdir("/mnt/efs"))
    target_file = os.path.join('/mnt/efs', target_file_name)
    shutil.copytree(file_type)

def copy_file(source_file, target_file_name, file_type):
    '''copy the file from local system to efs volume'''
    try:
        
        logger.info('copy_file target_file_name: %s', target_file_name)
        logger.info('copy_file source_file: %s', source_file)
        logger.info('efs local mount directory: %s', os.listdir("/mnt/efs"))
        target_file = os.path.join('/mnt/efs', file_type, target_file_name)
        #target_dir = os.path.join('/mnt/efs', target_file_name)
        # os.mkdir(target_dir)
        try:
            os.makedirs(os.path.dirname(target_file), exist_ok=True)
            logger.info("Now copying files from %s to %s", source_file, target_file)
            logger.info('efs local mount directory: %s', os.listdir("/mnt/efs"))
            shutil.copyfile(source_file, target_file)
        except OSError as FileError:
            logger.info('efs local mount directory: %s', os.listdir("/mnt/efs"))
            logger.error("Error when copying file into efs")
            logger.error(FileError)
    except OSError as Error:
            logger.error(Error)
    except TypeError as TyoeError:
        logger.error("Error when copying file into efs there is an empty directory")
        logger.error(TyoeError)

def change_file_owner(target_file_name, file_type, target_owner, target_group):
    '''change the owner of the target file'''
    target_file = os.path.join('/mnt/efs', file_type, target_file_name)
    shutil.chown(target_file,user=target_owner, group=target_group)


class EfsTrigger:
    '''EFS lambda trigger code'''
    def __init__(self):
        self.s3_client = boto3.client('s3')

    def download_from_s3(self, bucket_name, object_name, target_file_name):
        '''download object from s3 to store on /tmp'''
        try:
            
            target_name = os.path.join('/tmp', target_file_name)
            logger.info('download from s3 target name: %s', target_name)
            logger.info('download from s3 object name: %s', object_name)
            logger.info('download from s3 bucket name: %s', bucket_name)
            self.s3_client.download_file(bucket_name, object_name, target_name)
            return target_name
        except OSError as Error:
            logger.error(Error)

    def run_migrations(self, event):
        '''entry point for the program'''
        for record in event['Records']:
            source_bucket = get_bucket_name(record)
            logger.info('this is the source_bucket %s ', source_bucket)
            file_type = get_object_type(record)
            logger.info('this is the file_type %s ', file_type)
            source_object_key = get_object_key(record)
            target_file_name = get_file_name_from_object_key(source_object_key)
            source_file = self.download_from_s3(source_bucket, source_object_key, target_file_name)
            logger.info('this is the file type %s and this is target file %s and this is source file %s',file_type,target_file_name, source_file )
            
            copy_file(source_file, target_file_name, file_type)
            # change_file_owner(target_file_name,
            #                   file_type,
            #                   os.environ.get('file_owner','pi-user'),
            #                   os.environ.get('file_group','pi-group'))

efs_trigger = EfsTrigger()

def lambda_handler(event, context):
    '''call this from AWS'''
    del context
    efs_trigger.run_migrations(event)

if __name__ == '__main__':
    lambda_handler(event={}, context={})
